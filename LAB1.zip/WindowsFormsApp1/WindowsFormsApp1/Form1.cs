﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private int car1Position;
        private int car2Position;
        private Random random;
        private bool raceEnded;
        public Form1()
        {
            InitializeComponent();
            car1Position = 0;
            car2Position = 0;
            random = new Random();
            raceEnded = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!raceEnded)
            {
                car1Position += random.Next(1, 10);
                label1.Text = $"CAR 1 = {car1Position}";
                pictureBox1.Left = car1Position;

                if (car1Position >= this.Width)
                {
                    MessageBox.Show("Car 1 wins the race!");
                    raceEnded = true;
                    timer1.Enabled = false;
                    timer2.Enabled = false;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (!raceEnded)
            {
                car2Position += random.Next(1, 10);
                label2.Text = $"CAR 2 = {car2Position}";
                pictureBox2.Left = car2Position;

                if (car2Position >= this.Width)
                {
                    MessageBox.Show("Car 2 wins the race!");
                    raceEnded = true;
                    timer1.Enabled = false;
                    timer2.Enabled = false;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            car1Position = 0;
            car2Position = 0;
            label1.Text = $"CAR 1 = {car1Position}";
            label2.Text = $"CAR 2 = {car2Position}";
            pictureBox1.Left = car1Position;
            pictureBox2.Left = car2Position;
            raceEnded = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
         if (MessageBox.Show("Program will terminate", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        }
        }
    }
