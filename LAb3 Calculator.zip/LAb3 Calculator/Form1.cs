﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAb3_Calculator
{
    public partial class Calculator : Form
    {
        private string currentCalculation = "";
      

        public Calculator()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            copyToolStripMenuItem.PerformClick();
            pasteToolStripMenuItem.PerformClick();
        }
        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Make by Surayut", "This is a calculator that somehow work like a calculator");
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Click to the button number to choose te numbers,Click to the operator to choose +,-,*,/ then press = for the result and CE to clear ", " How to use ");
        }
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(currentCalculation))
            {
                Clipboard.SetText(currentCalculation);
            }
        }
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            currentCalculation += Clipboard.GetText();
            
            textBox1.Text = currentCalculation;
        }
        private void button_Click(object sender, EventArgs e)
        {
            string buttonText = (sender as Button).Text;
            currentCalculation += buttonText;
            textBox1.Text = currentCalculation;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button14equal_Click(object sender, EventArgs e)
        {
            try
            {
                
                DataTable table = new DataTable();
                var result = table.Compute(currentCalculation, "");

                textBox1.Text = result.ToString();
                currentCalculation = result.ToString();
            }
            catch (Exception ex)
            {
               
                textBox1.Text = "Error";
                currentCalculation = "";
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            currentCalculation = "";
        }

        private void copyToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void pasteToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }
    }

   

}
