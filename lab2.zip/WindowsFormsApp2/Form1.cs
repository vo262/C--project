﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConvertUnits();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConvertUnits();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            SetUnitCategories();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            SetUnitCategories();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            SetUnitCategories();
        }
        private void SetUnitCategories()
        {
            
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            
            if (radioButton1.Checked)
            {
                comboBox1.Items.AddRange(new string[] { "Meter", "Kilometer", "Centimeter", "Inch", "Foot", "Mile" });
                comboBox2.Items.AddRange(new string[] { "Meter", "Kilometer", "Centimeter", "Inch", "Foot", "Mile" });
            }
            else if (radioButton2.Checked)
            {
                comboBox1.Items.AddRange(new string[] { "Square Meter", "Square Kilometer", "Square Centimeter", "Square Inch", "Square Foot", "Square Mile" });
                comboBox2.Items.AddRange(new string[] { "Square Meter", "Square Kilometer", "Square Centimeter", "Square Inch", "Square Foot", "Square Mile" });
            }
            else if (radioButton3.Checked)
            {
                comboBox1.Items.AddRange(new string[] { "Cubic Meter", "Cubic Kilometer", "Cubic Centimeter", "Cubic Inch", "Cubic Foot", "Cubic Mile" });
                comboBox2.Items.AddRange(new string[] { "Cubic Meter", "Cubic Kilometer", "Cubic Centimeter", "Cubic Inch", "Cubic Foot", "Cubic Mile" });
            }

            
            textBox1.Focus();
        }

        private void ConvertUnits()
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                string unitFrom = comboBox1.SelectedItem.ToString();
                string unitTo = comboBox2.SelectedItem.ToString();
                double value = double.Parse(textBox1.Text);

                double result = UnitConverter.Convert(unitFrom, unitTo, value);

                if (!double.IsNaN(result))
                {
                    textBox2.Text = result.ToString();
                }
                else
                {
                    MessageBox.Show("Invalid conversion units.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }

}
public static class UnitConverter
{
    public static double Convert(string unitFrom, string unitTo, double value)
    {
        
        Dictionary<string, Dictionary<string, double>> conversionFactors = new Dictionary<string, Dictionary<string, double>>
        {
            
            {
                "Meter", new Dictionary<string, double>
                {
                    {"Meter", 1.0},
                    {"Kilometer", 0.001},
                    {"Centimeter", 100.0},
                    {"Inch", 39.3701},
                    {"Foot", 3.28084},
                    {"Mile", 0.000621371}
                }
            },
            
            {
                "Square Meter", new Dictionary<string, double>
                {
                    {"Square Meter", 1.0},
                    {"Square Kilometer", 0.000001},
                    {"Square Centimeter", 10000.0},
                    {"Square Inch", 1550.0031},
                    {"Square Foot", 10.7639},
                    {"Square Mile", 3.861e-7}
                }
            },
            
            {
                "Cubic Meter", new Dictionary<string, double>
                {
                    {"Cubic Meter", 1.0},
                    {"Cubic Kilometer", 1e-9},
                    {"Cubic Centimeter", 1e6},
                    {"Cubic Inch", 61023.7},
                    {"Cubic Foot", 35.3147},
                    {"Cubic Mile", 2.3991e-10}
                }
            }
        };

       
        if (conversionFactors.ContainsKey(unitFrom) && conversionFactors[unitFrom].ContainsKey(unitTo))
        {
            double conversionFactor = conversionFactors[unitFrom][unitTo];
            return value * conversionFactor;
        }

       
        return double.NaN;
    }
}

